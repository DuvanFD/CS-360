package com.example.cs360inventoryappduvandiaz;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class DataActivity extends AppCompatActivity {

    private TextView dataTextView;
    private ArrayList<String> dataList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data);


        dataTextView = findViewById(R.id.dataRecyclerView);
        Button addDataButton = findViewById(R.id.addDataButton);


        dataList = new ArrayList<>();
        updateDataDisplay(); // Show initial empty state


        addDataButton.setOnClickListener(v -> {
            int newItemNumber = dataList.size() + 1;
            dataList.add("Item " + newItemNumber);
            updateDataDisplay();
            Toast.makeText(DataActivity.this, "Inventory item " + newItemNumber + "  has been added", Toast.LENGTH_SHORT).show();
        });


        dataTextView.setOnClickListener(v -> {
            if (!dataList.isEmpty()) {
                String removedItem = dataList.remove(dataList.size() - 1);
                updateDataDisplay();
                Toast.makeText(DataActivity.this, removedItem + " Inventory Removed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(DataActivity.this, "No Inventory items to remove", Toast.LENGTH_SHORT).show();
            }
        });
    }


    @SuppressLint("SetTextI18n")
    private void updateDataDisplay() {
        if (dataList.isEmpty()) {
            dataTextView.setText("No Inventory Items yet. Please feel free to add.");
        } else {
            StringBuilder displayText = new StringBuilder();
            for (String item : dataList) {
                displayText.append(item).append("\n");
            }
            dataTextView.setText(displayText.toString());
        }
    }
}
