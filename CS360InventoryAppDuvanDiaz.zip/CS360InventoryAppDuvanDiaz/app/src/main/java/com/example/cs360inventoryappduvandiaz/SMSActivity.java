package com.example.cs360inventoryappduvandiaz;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_REQUEST_CODE = 100;
    private TextView smsStatusTextView;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        smsStatusTextView = findViewById(R.id.smsStatusTextView);
        Button requestSmsPermissionButton = findViewById(R.id.requestSmsPermissionButton);


        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            smsStatusTextView.setText("Permission Status: Granted");

            sendSMS("Inventory Alert", "Low Inventory! Please restock.");
        } else {
            smsStatusTextView.setText("Permission Status: Denied");
        }


        requestSmsPermissionButton.setOnClickListener(v -> {
            requestSmsPermission();
        });
    }


    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_REQUEST_CODE);
        }
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);


        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                smsStatusTextView.setText("Permission Status: Granted");
                Toast.makeText(this, "SMS Permission Granted", Toast.LENGTH_SHORT).show();
                // Send SMS
                sendSMS("Inventory Alert", "Low Inventory! Please restock.");
            } else {
                // Permission denied
                smsStatusTextView.setText("No good. Permission Status: Denied");
                Toast.makeText(this, "SMS Permission Denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void sendSMS(String subject, String body) {
        String phoneNumber = "20199999999";
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, null, body, null, null);
    }
}
